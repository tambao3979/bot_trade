"""
Meta strategy that routes to the best sub-strategy based on regime.
T13.

This implementation does not instantiate sub-strategy classes;
it computes all signals inline to avoid object duplication and
keep the routing logic explicit.
"""

from __future__ import annotations

import pandas as pd

try:
    from base.BaseRiskStrategy import BaseRiskStrategy
    from lib.indicators import adx, atr, bbands, ema, rsi, vol_ma, vwap_session
except ModuleNotFoundError:
    from user_data.strategies.base.BaseRiskStrategy import BaseRiskStrategy
    from user_data.strategies.lib.indicators import (
        adx,
        atr,
        bbands,
        ema,
        rsi,
        vol_ma,
        vwap_session,
    )


class MetaRouter(BaseRiskStrategy):
    timeframe = "15m"

    can_short = True

    def informative_pairs(self):
        return [("BTC/USDC:USDC", "1h")]

    def populate_indicators(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        # Common indicators used by all sub-strategies
        dataframe["ema21"] = ema(dataframe["close"], 21)
        dataframe["rsi14"] = rsi(dataframe["close"], 14)
        dataframe["atr14"] = atr(dataframe, 14)
        dataframe["vol_ma20"] = vol_ma(dataframe, 20)
        dataframe["adx14"] = adx(dataframe, 14)

        bb = bbands(dataframe, 20, 2)
        dataframe["bb_lower"] = bb["bb_lower"]
        dataframe["bb_mid"] = bb["bb_mid"]
        dataframe["bb_upper"] = bb["bb_upper"]

        dataframe["vwap"] = vwap_session(dataframe)

        # Simple session range (same logic as LiquiditySweep)
        dataframe["prev_session_high"] = dataframe["high"].rolling(96).max().shift(1)
        dataframe["prev_session_low"] = dataframe["low"].rolling(96).min().shift(1)

        dataframe["regime_1h"] = self.informative_regime(dataframe)

        return dataframe

    def populate_entry_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        dataframe["enter_long"] = 0
        dataframe["enter_short"] = 0
        dataframe["enter_tag"] = ""

        # --- Setup A: TrendPullback ---
        # Only used when regime is a trend
        trend_mask = dataframe["regime_1h"].isin(["trend_up", "trend_down"])

        long_a = (
            (dataframe["regime_1h"] == "trend_up")
            & (dataframe["low"] <= dataframe["ema21"])
            & (dataframe["close"] > dataframe["ema21"])
            & (dataframe["rsi14"].shift(1) < 50)
            & (dataframe["rsi14"] > 50)
            & (dataframe["volume"] > 1.2 * dataframe["vol_ma20"])
        )

        short_a = (
            (dataframe["regime_1h"] == "trend_down")
            & (dataframe["high"] >= dataframe["ema21"])
            & (dataframe["close"] < dataframe["ema21"])
            & (dataframe["rsi14"].shift(1) > 50)
            & (dataframe["rsi14"] < 50)
            & (dataframe["volume"] > 1.2 * dataframe["vol_ma20"])
        )

        dataframe.loc[trend_mask & long_a, "enter_long"] = 1
        dataframe.loc[trend_mask & short_a, "enter_short"] = 1
        dataframe.loc[trend_mask & long_a, "enter_tag"] = "trend_pullback_long"
        dataframe.loc[trend_mask & short_a, "enter_tag"] = "trend_pullback_short"

        # --- Setup C: RangeReversion ---
        range_mask = dataframe["regime_1h"] == "range"

        long_c = (
            (dataframe["close"] <= dataframe["bb_lower"])
            & (dataframe["rsi14"] < 30)
            & (dataframe["close"] <= dataframe["vwap"] * 0.98)
        )

        short_c = (
            (dataframe["close"] >= dataframe["bb_upper"])
            & (dataframe["rsi14"] > 70)
            & (dataframe["close"] >= dataframe["vwap"] * 1.02)
        )

        dataframe.loc[range_mask & long_c, "enter_long"] = 1
        dataframe.loc[range_mask & short_c, "enter_short"] = 1
        dataframe.loc[range_mask & long_c, "enter_tag"] = "range_reversion_long"
        dataframe.loc[range_mask & short_c, "enter_tag"] = "range_reversion_short"

        # --- Setup B: LiquiditySweep ---
        # Sweep signals can run in parallel but are limited by regime != chaos
        sweep_mask = dataframe["regime_1h"] != "chaos"

        in_killzone = (
            (dataframe["date"].dt.hour >= 7)
            & (dataframe["date"].dt.hour <= 15)
        )

        long_b = (
            (dataframe["low"] < dataframe["prev_session_low"])
            & (dataframe["close"] > dataframe["prev_session_low"])
            & (dataframe["volume"] > 0)
            & in_killzone
        )

        short_b = (
            (dataframe["high"] > dataframe["prev_session_high"])
            & (dataframe["close"] < dataframe["prev_session_high"])
            & (dataframe["volume"] > 0)
            & in_killzone
        )

        # Liquidity sweeps are a fallback route. They do not overwrite a
        # regime-specific signal already selected above.
        sweep_long = sweep_mask & long_b & (dataframe["enter_long"] == 0)
        sweep_short = sweep_mask & short_b & (dataframe["enter_short"] == 0)
        dataframe.loc[sweep_long, "enter_long"] = 1
        dataframe.loc[sweep_short, "enter_short"] = 1
        dataframe.loc[sweep_long, "enter_tag"] = "liquidity_sweep_long"
        dataframe.loc[sweep_short, "enter_tag"] = "liquidity_sweep_short"

        # Freqtrade rejects conflicting entries, but resolving them here keeps
        # routing deterministic and makes the backtest signal stream explicit.
        conflict = (dataframe["enter_long"] == 1) & (dataframe["enter_short"] == 1)
        dataframe.loc[conflict, ["enter_long", "enter_short"]] = 0
        dataframe.loc[conflict, "enter_tag"] = ""

        return dataframe

    def populate_exit_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        dataframe["exit_long"] = 0
        dataframe["exit_short"] = 0

        # Exit signals from all sub-strategies
        # TrendPullback: RSI extreme
        dataframe.loc[dataframe["rsi14"] > 75, "exit_long"] = 1
        dataframe.loc[dataframe["rsi14"] < 25, "exit_short"] = 1

        # RangeReversion: exit at mid-band / VWAP only in range regime. Applying
        # it to a trend would immediately close most valid trend-pullback trades.
        range_mask = dataframe["regime_1h"] == "range"
        dataframe.loc[range_mask & (dataframe["close"] >= dataframe["bb_mid"]), "exit_long"] = 1
        dataframe.loc[range_mask & (dataframe["close"] <= dataframe["bb_mid"]), "exit_short"] = 1

        # LiquiditySweep: close beyond previous session levels
        dataframe.loc[
            dataframe["close"] < dataframe["prev_session_low"], "exit_long"
        ] = 1
        dataframe.loc[
            dataframe["close"] > dataframe["prev_session_high"], "exit_short"
        ] = 1

        return dataframe
