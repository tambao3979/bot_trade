"""
Setup A – Trend Pullback (T10).
Long: pullback into fib/EMA21, RSI cross above 50, volume expansion.
Short: mirror image.
"""

from __future__ import annotations

import pandas as pd
from freqtrade.strategy import DecimalParameter

try:
    from base.BaseRiskStrategy import BaseRiskStrategy
    from lib.indicators import adx, atr, ema, rsi, vol_ma
except ModuleNotFoundError:
    from user_data.strategies.base.BaseRiskStrategy import BaseRiskStrategy
    from user_data.strategies.lib.indicators import adx, atr, ema, rsi, vol_ma


class TrendPullback(BaseRiskStrategy):
    timeframe = "15m"

    process_only_new_candles = True

    use_exit_signal = True

    can_short = True

    # Hyperopt candidates (≤6 parameters per T14)
    pullback_fib_lo = DecimalParameter(0.382, 0.618, default=0.5, space="buy")
    pullback_fib_hi = DecimalParameter(0.618, 0.786, default=0.7, space="buy")
    volume_mult = DecimalParameter(1.1, 1.5, default=1.2, space="buy")

    def informative_pairs(self):
        return [("BTC/USDC:USDC", "1h"), ("ETH/USDC:USDC", "1h")]

    def populate_indicators(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        dataframe["ema21"] = ema(dataframe["close"], 21)
        dataframe["rsi14"] = rsi(dataframe["close"], 14)
        dataframe["atr14"] = atr(dataframe, 14)
        dataframe["vol_ma20"] = vol_ma(dataframe, 20)
        dataframe["adx14"] = adx(dataframe, 14)

        dataframe["regime_1h"] = self.informative_regime(dataframe)

        return dataframe

    def populate_entry_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        cond_long = (
            (dataframe["regime_1h"] == "trend_up")
            & (dataframe["low"] <= dataframe["ema21"])
            & (dataframe["close"] > dataframe["ema21"])
            & (dataframe["rsi14"].shift(1) < 50)
            & (dataframe["rsi14"] > 50)
            & (dataframe["volume"] > self.volume_mult.value * dataframe["vol_ma20"])
        )
        cond_short = (
            (dataframe["regime_1h"] == "trend_down")
            & (dataframe["high"] >= dataframe["ema21"])
            & (dataframe["close"] < dataframe["ema21"])
            & (dataframe["rsi14"].shift(1) > 50)
            & (dataframe["rsi14"] < 50)
            & (dataframe["volume"] > self.volume_mult.value * dataframe["vol_ma20"])
        )
        dataframe.loc[cond_long, "enter_long"] = 1
        dataframe.loc[cond_short, "enter_short"] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        # Base strategy handles profit-based exits;
        # signals here are optional safe exits.
        dataframe.loc[dataframe["rsi14"] > 75, "exit_long"] = 1
        dataframe.loc[dataframe["rsi14"] < 25, "exit_short"] = 1
        return dataframe
