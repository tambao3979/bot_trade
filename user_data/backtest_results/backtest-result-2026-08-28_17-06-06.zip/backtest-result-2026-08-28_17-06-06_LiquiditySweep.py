"""
Setup B – Liquidity Sweep (T11).
"""

from __future__ import annotations

import pandas as pd

try:
    from base.BaseRiskStrategy import BaseRiskStrategy
    from lib.indicators import atr
except ModuleNotFoundError:
    from user_data.strategies.base.BaseRiskStrategy import BaseRiskStrategy
    from user_data.strategies.lib.indicators import atr


class LiquiditySweep(BaseRiskStrategy):
    timeframe = "15m"

    can_short = True

    # Configurable killzone hours (UTC)
    killzone_start = 7
    killzone_end = 15

    def informative_pairs(self):
        return [("BTC/USDC:USDC", "1h")]

    def populate_indicators(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        dataframe["atr14"] = atr(dataframe, 14)
        dataframe["regime_1h"] = self.informative_regime(dataframe)

        # Simple session range using last day's high/low
        dataframe["prev_session_high"] = dataframe["high"].rolling(96).max().shift(1)
        dataframe["prev_session_low"] = dataframe["low"].rolling(96).min().shift(1)
        return dataframe

    def populate_entry_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        in_killzone = (
            (dataframe["date"].dt.hour >= self.killzone_start)
            & (dataframe["date"].dt.hour <= self.killzone_end)
        )
        # Simplify: entry when price sweeps previous session low and closes above it
        cond_long = (
            (dataframe["regime_1h"] != "chaos")
            & (dataframe["low"] < dataframe["prev_session_low"])
            & (dataframe["close"] > dataframe["prev_session_low"])
            & (dataframe["volume"] > 0)
            & in_killzone
        )
        cond_short = (
            (dataframe["regime_1h"] != "chaos")
            & (dataframe["high"] > dataframe["prev_session_high"])
            & (dataframe["close"] < dataframe["prev_session_high"])
            & (dataframe["volume"] > 0)
            & in_killzone
        )
        dataframe.loc[cond_long, "enter_long"] = 1
        dataframe.loc[cond_short, "enter_short"] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        dataframe.loc[dataframe["close"] < dataframe["prev_session_low"], "exit_long"] = 1
        dataframe.loc[dataframe["close"] > dataframe["prev_session_high"], "exit_short"] = 1
        return dataframe
