"""
Setup C – Range Reversion (T12).
"""

from __future__ import annotations

import pandas as pd

try:
    from base.BaseRiskStrategy import BaseRiskStrategy
    from lib.indicators import bbands, rsi, vwap_session
except ModuleNotFoundError:
    from user_data.strategies.base.BaseRiskStrategy import BaseRiskStrategy
    from user_data.strategies.lib.indicators import bbands, rsi, vwap_session


class RangeReversion(BaseRiskStrategy):
    timeframe = "15m"

    can_short = True

    def informative_pairs(self):
        return [("BTC/USDC:USDC", "1h")]

    def populate_indicators(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        dataframe["rsi14"] = rsi(dataframe["close"], 14)
        bb = bbands(dataframe, 20, 2)
        dataframe["bb_lower"] = bb["bb_lower"]
        dataframe["bb_mid"] = bb["bb_mid"]
        dataframe["bb_upper"] = bb["bb_upper"]
        dataframe["vwap"] = vwap_session(dataframe)

        dataframe["regime_1h"] = self.informative_regime(dataframe)
        return dataframe

    def populate_entry_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        cond_long = (
            (dataframe["regime_1h"] == "range")
            & (dataframe["close"] <= dataframe["bb_lower"])
            & (dataframe["rsi14"] < 30)
            & (dataframe["close"] <= dataframe["vwap"] * 0.98)
        )
        cond_short = (
            (dataframe["regime_1h"] == "range")
            & (dataframe["close"] >= dataframe["bb_upper"])
            & (dataframe["rsi14"] > 70)
            & (dataframe["close"] >= dataframe["vwap"] * 1.02)
        )
        dataframe.loc[cond_long, "enter_long"] = 1
        dataframe.loc[cond_short, "enter_short"] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        # Exit at mid-band / VWAP
        dataframe.loc[dataframe["close"] >= dataframe["bb_mid"], "exit_long"] = 1
        dataframe.loc[dataframe["close"] <= dataframe["bb_mid"], "exit_short"] = 1
        return dataframe
