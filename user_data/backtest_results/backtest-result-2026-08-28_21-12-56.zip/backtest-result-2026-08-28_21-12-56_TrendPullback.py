"""
Setup A – Trend Pullback (T10).
Long: pullback into EMA, RSI momentum, volume confirmation.
Short: mirror image.
"""

from __future__ import annotations

import pandas as pd
from freqtrade.strategy import DecimalParameter

try:
    from base.BaseRiskStrategy import BaseRiskStrategy
    from lib.indicators import adx, atr, ema, rsi, vol_ma
except ModuleNotFoundError:
    from user_data.strategies.base.BaseRiskStrategy import BaseRiskStrategy
    from user_data.strategies.lib.indicators import adx, atr, ema, rsi, vol_ma


class TrendPullback(BaseRiskStrategy):
    timeframe = "15m"

    process_only_new_candles = True

    use_exit_signal = False

    can_short = True

    # Hyperopt parameters
    volume_mult = DecimalParameter(0.4, 1.2, default=0.7, space="buy")
    rsi_pullback_min = DecimalParameter(40.0, 50.0, default=45.0, space="buy")
    rsi_pullback_max = DecimalParameter(60.0, 72.0, default=68.0, space="buy")

    def informative_pairs(self):
        return [("BTC/USDC:USDC", "1h"), ("ETH/USDC:USDC", "1h")]

    def populate_indicators(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        dataframe["ema20"] = ema(dataframe["close"], 20)
        dataframe["ema50"] = ema(dataframe["close"], 50)
        dataframe["ema200"] = ema(dataframe["close"], 200)
        dataframe["rsi14"] = rsi(dataframe["close"], 14)
        dataframe["atr14"] = atr(dataframe, 14)
        dataframe["vol_ma20"] = vol_ma(dataframe, 20)
        dataframe["adx14"] = adx(dataframe, 14)

        dataframe["regime_1h"] = self.informative_regime(dataframe)

        return dataframe

    def populate_entry_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        cond_long = (
            (dataframe["regime_1h"] == "trend_up")
            & (dataframe["ema20"] > dataframe["ema50"])
            & (dataframe["close"] > dataframe["ema200"])
            & (dataframe["low"] <= dataframe["ema20"] * 1.002)
            & (dataframe["close"] >= dataframe["ema20"])
            & (dataframe["close"] > dataframe["open"])
            & (dataframe["rsi14"] >= self.rsi_pullback_min.value)
            & (dataframe["rsi14"] <= self.rsi_pullback_max.value)
            & (dataframe["rsi14"] >= dataframe["rsi14"].shift(1))
            & (dataframe["adx14"] >= 18)
            & (dataframe["volume"] > self.volume_mult.value * dataframe["vol_ma20"])
        )
        cond_short = (
            (dataframe["regime_1h"] == "trend_down")
            & (dataframe["ema20"] < dataframe["ema50"])
            & (dataframe["close"] < dataframe["ema200"])
            & (dataframe["high"] >= dataframe["ema20"] * 0.998)
            & (dataframe["close"] <= dataframe["ema20"])
            & (dataframe["close"] < dataframe["open"])
            & (dataframe["rsi14"] <= 100 - self.rsi_pullback_min.value)
            & (dataframe["rsi14"] >= 100 - self.rsi_pullback_max.value)
            & (dataframe["rsi14"] <= dataframe["rsi14"].shift(1))
            & (dataframe["adx14"] >= 18)
            & (dataframe["volume"] > self.volume_mult.value * dataframe["vol_ma20"])
        )
        dataframe.loc[cond_long, "enter_long"] = 1
        dataframe.loc[cond_short, "enter_short"] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        dataframe["exit_long"] = 0
        dataframe["exit_short"] = 0
        return dataframe
